#include "my_malloc.h"
#include "assert.h"

//smallest split value. If left space is less than the value, then split will not happen
#define MIN_SPLIT_SIZE 32

// the implementation of ff_mallpc
void* ff_malloc(size_t size){
  if(size == 0){
    return NULL;
  }
  if(base == NULL){
    block_t* pos = newBlock(size);
    if(pos == NULL){
      return NULL;
    }
    base = (void*) pos;
    return (char*)pos + sizeof(block_t);
  }else{
    if(freehead == NULL){
      block_t* pos = newBlock(size);
      if(pos == NULL){
	return NULL;
      }
      return (char*)pos + sizeof(block_t);
    }else{
      if(freehead->size >= size){
	void* ans = (void*)((char*)freehead + sizeof(block_t));
	if(freehead->size >= size + sizeof(block_t) + MIN_SPLIT_SIZE){
	  block_t* new = (block_t*)((char*)freehead + sizeof(block_t) + size);
	  new->free = freehead->free;
	  new->size = freehead->size - sizeof(block_t) - size;
	  freehead->size = size;
	  freehead->free = NULL;
	  freehead = new;
	}else{
	  block_t* curr = freehead;
	  freehead = freehead->free;
	  curr->free = NULL;
	}
	return ans;
      }
      block_t* p = freehead;
      while(p->free != NULL){
	if(p->free->size >= size){
	  void* ans = (char*)(p->free)+sizeof(block_t);
	  if(p->free->size >= size + sizeof(block_t) + MIN_SPLIT_SIZE){
	    block_t* new = (block_t*)((char*)(p->free) + sizeof(block_t) + size);
	    new->free = p->free->free;
	    new->size = p->free->size - sizeof(block_t) - size;
	    p->free->size = size;
	    p->free->free = NULL;
	    p->free = new;
	  }
	  else{
	    block_t* curr = p->free;
	    p->free = p->free->free;
	    curr->free = NULL;
	  }
	  return ans;
	}
	p = p->free;
      }
      block_t* pos = newBlock(size);
      if(pos==NULL){
	return NULL;
      }
      return (char*)pos + sizeof(block_t);
    }
  }
}

//the implementation of first fit free policy
void ff_free(void* ptr){
  if(ptr == NULL){
    return;
  }
  block_t* b = getBlock(ptr);
  assert(b->free == NULL);
  
  if(freehead == NULL){
    freehead = b;
    b->free = NULL;
    return;
  }
  block_t* prev = NULL;
  block_t* curr = freehead;

  while(curr != NULL && curr < b){
    prev = curr;
    curr = curr->free;
  }
  
  if(prev != NULL && (char*)prev + sizeof(block_t) + prev->size == (char*)b){
    prev->size += sizeof(block_t) + b->size;
    b = prev;
  }
  else{
    if(prev == NULL){
      b->free = freehead;
      freehead = b;
    }else{
      b->free = prev->free;
      prev->free = b;
    }
  }

  if(b->free != NULL && (char*)b + sizeof(block_t) + b->size == (char*)(b->free)){
    b->size += sizeof(block_t) + b->free->size;
    block_t* next = b->free;
    b->free = next->free;
    next->free = NULL;
  }
}

void* bf_malloc(size_t size){
  if(size == 0){
    return NULL;
  }
  if(base == NULL){
    block_t* pos = newBlock(size);
    if(pos == NULL){
      return NULL;
    }
    base = (void*)pos;
    return (char*)pos + sizeof(block_t);
  }else{
    if(freehead == NULL){
      block_t* pos = newBlock(size);
      if(pos == NULL){
	return NULL;
      }
      return (char*)pos + sizeof(block_t);
    }else{
      block_t* best_block = NULL;
      block_t* best_prev = NULL;
      size_t best_diff = UINT_MAX;
      
      if(freehead->size >= size){
	if(freehead->size == size){
	  void* ans = (void*)((char*)freehead + sizeof(block_t));
	  block_t* curr = freehead;
	  freehead = freehead->free;
	  curr->free = NULL;
	  return ans;
	}
	best_diff = freehead->size - size;
	best_block = freehead;
	best_prev = NULL;
      }
      block_t* p = freehead;
      while(p->free != NULL){
	if(p->free->size == size){
	  void* ans = (void*)((char*)(p->free) + sizeof(block_t));
	  block_t* curr = p->free;
	  p->free = p->free->free;
	  curr->free = NULL;
	  return ans;
	}
	if(p->free->size > size){
	  size_t diff = p->free->size - size;
	  if(diff < best_diff){
	    best_diff = diff;
	    best_block = p->free;
	    best_prev = p;
	  }
	}
	p = p->free;
}

  if(best_block == NULL){
	block_t* pos = newBlock(size);
	if(pos == NULL){
	  return NULL;
	}
	return (char*)pos + sizeof(block_t);
}
  void* ans = (void*)((char*)best_block + sizeof(block_t));

  if(best_block->size >= size + sizeof(block_t) + MIN_SPLIT_SIZE){
	block_t* new = (block_t*)((char*)best_block + sizeof(block_t) + size);
	block_t* next_in_list = best_block->free; // Save the next block in list
	new->size = best_block->size - sizeof(block_t) - size;
	best_block->size = size;
	best_block->free = NULL;
	
	if(best_prev == NULL){
	  new->free = next_in_list;
	  freehead = new;
	}
	else{
	  new->free = next_in_list;
	  best_prev->free = new;
	}
      }
      else{
	if(best_prev == NULL){
	  freehead = best_block->free;
	}
	else{
	  best_prev->free = best_block->free;
	}
	best_block->free = NULL;
      }
      
      return ans;
    }
  }
}

void bf_free(void* ptr){
  ff_free(ptr);
  return;
}


block_t* newBlock(size_t size){
  block_t* b = sbrk(0);
  if(sbrk(size+sizeof(block_t))==(void*)-1){//sbrk failed
    return NULL;
  }
  b->size = size;
  b->free = NULL;
  return b;
}

block_t* getBlock(void* ptr){
  block_t* b = (block_t*)((char*)ptr - sizeof(block_t));
  return b;
}

unsigned long get_largest_free_data_segment_size(){
  block_t* curr = freehead;
  unsigned long max_size = 0;
  while(curr != NULL){
    if(curr->size > max_size){
      max_size = curr->size;
    }
    curr = curr->free;
  }
  return max_size;
}

unsigned long get_total_free_size(){
  block_t* curr = freehead;
  unsigned long res = 0;
  while(curr != NULL){
    res += curr->size;
    curr = curr->free;
  }
  return res;
}

